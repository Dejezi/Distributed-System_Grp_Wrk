import java.net.UnknownHostException;
import java.rmi.*;

public class Group
{
    String name;
    Sequencer remote;
    SequencerJoinInfo info;

    public Group(String host, String senderName)  throws GroupException, UnknownHostException
    {
        this.name = senderName;
        try 
        {
            remote = (Sequencer)Naming.lookup("rmi://localhost:1919"+"/seq");            
            // contact Sequencer on "host" to join group,
            info = remote.join(name); 
            if(info == null)
            {
                System.out.println(name + " is already taken choose another username.");
                System.exit(0); // This terminates the client program because the name is already in use.
            }           
        } catch (Exception e) 
        {
            System.out.println("Failed to initialize sequencer " + e);
        }
    }

    public void send(String msg) throws GroupException, RemoteException
    {
        // send the given message to all instances of Group using the same sequencer
        remote.sendToSequencer(msg, name);
    }

    public void leave() throws RemoteException
    {
       // leave group
       remote.leave(name);
    }

    public class GroupException extends Exception
    {
        public GroupException(String s)
        {
            super(s);
        }
    }

    public void heartBeater() throws RemoteException 
    {
        // This thread sends heartbeat messages when required
        remote.heart(name);
    }
} 
