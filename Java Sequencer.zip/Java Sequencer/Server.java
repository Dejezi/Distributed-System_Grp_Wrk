import java.rmi.*;
import java.rmi.registry.*;

public class Server { 
    public static void main(String args[])
	{
		try
		{
			SequencerImpl obj = new SequencerImpl("Sequencer");

			// rmiregistry within the server JVM with
			// port number 1919
			LocateRegistry.createRegistry(1919);

			// Binds the remote object by the name
			Naming.rebind("rmi://localhost:1919"+"/seq", obj);
            System.out.println("\nThe Server is now running*****");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
} 